<div align="center">
  <img src="https://media.discordapp.net/attachments/1067534469554245652/1092442307250360520/Random_Scripts_I_Sometimes_Make_With_Varying_Degrees_Of_Coding_Success.png?width=1325&height=662">
  <h1>BG's Blacket Utilities</h1>
  <h3>(Nowhere near as good as Death's)</h3>
  <h3><a href="https://discord.gg/blacket">Blacket Discord</a></h3>
</div>

</details>
<details>
<summary align="center"><h2>Scripts</h2></summary>

### [Global](Global/)
 * [Unblock Console](Global/UnblockConsole.js) // Prevents heartbeats and system logs in the console from taking up space.<br>
 * [Rainbow Theme](Global/RainbowTheme.js) // Turns everything onto the page into a different random color.<br>
 * [Ben Stewart Images](Global/BenStewartImages.js) // Changes every image on a page to an image of Ben Stewart's face.<br>
